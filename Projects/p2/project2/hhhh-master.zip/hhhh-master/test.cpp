#include <iostream>
#include <cstdlib>

using namespace std;
int main(){
    int n = 0;
    char b = n;
    cout << b << endl;
    return 0;
}
